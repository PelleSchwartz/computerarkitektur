/*
 * func3.h
 *
 *  Created on: 19. nov. 2018
 *      Author: psz
 */
#pragma once
#include "typenames.h"
#include <iostream>
using namespace std;

#ifndef FUNC3_H_
#define FUNC3_H_

unsigned char rTypeFunc3(uint32_t inst);
unsigned char i3TypeFunc3(uint32_t inst);
unsigned char i19TypeFunc3(uint32_t inst);
unsigned char sTypeFunc3(uint32_t inst);
unsigned char bTypeFunc3(uint32_t inst);

#endif /* FUNC3_H_ */
