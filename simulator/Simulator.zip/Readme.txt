This file contains all test files made by the program. Makefile is not tested on linux systems so might not work.

The release folder contains the program but the exe file in there does not run through instructions as expected.